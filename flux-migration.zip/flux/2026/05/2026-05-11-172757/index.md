---
id: 2026-05-11-172757
date: '2026-05-11T17:27:57+08:00'
title: 11 May, 2026 17:27
source: wordpress-live
sync: manual
source_hash: 95d75e8d095389d1
wp_post_id: 2686
wp_url: https://fivsevn.com/2026/05/11/11-may-2026-1727/
wp_slug: 11-may-2026-1727
status: published
---

印尼etc.

> 根据德瑞克的汜載：“葡萄牙人……欲立专制政府以号令地方百姓..残杀国王。”他们的计划引火自焚；特尔纳特老百姓群起反抗，赶走了葡萄牙人。于是其他欧洲人——西班牙人、英国人、荷兰人——接踵而至，竞相在马鲁古群岛采购香料卖到欧洲，导致产地价格上涨，欧洲利润下跌，令远洋贸易商大感不悦。1602年，荷兰商人决定采取行动，联合成立荷兰东印度公司。
>
> 东印度公司是全世界第一家股份有限公司，初期投资者达一千八百人。公司成立后大肆宣传，带动了世界最早的股市交易；第一艘商船尚未起航，初期投资者便哄抬价格，出售手中股票。十七位董事承受巨大压力，必须为股票持有人创造利润。他们提高获利的第一步是：垄断香料市场，剔除来自其他欧洲人的竞争，实行策略则是：贿赂＋笼络＋暴力。

位于雅加达的【Wayang博物馆】可以看到 VOC（The United East India Company, Dutch: Vereenigde Oostindische Compagnie）相关遗迹。可参考：<https://en.wikipedia.org/wiki/Wayang_Museum>
