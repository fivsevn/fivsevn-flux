---
id: 2026-04-24-044858
date: '2026-04-24T04:48:58+08:00'
title: 24 April, 2026 04:48
source: wordpress-live
sync: manual
source_hash: b65334f51d48d7d6
wp_post_id: 2656
wp_url: https://fivsevn.com/2026/04/24/24-april-2026-0448/
wp_slug: 24-april-2026-0448
status: published
---

正在重看《麦田里的守望者》。以前因为最喜欢的神山健治版的《攻壳机动队》，tv版的笑面人事件有引用这本书，所以好奇去看的，看到最后也不知为何哭得稀里哗啦的。现在因为看阿内特的青少年心理学，又提到了这本书，所以再回顾一下看看有没有新的感悟。反正之前看过的也忘了大半了；但我记得看到结局不知为啥爆哭了一下。
