---
id: 2026-03-04-180809
date: '2026-03-04T18:08:09+08:00'
title: 4 March, 2026 18:08
source: wordpress-live
sync: manual
source_hash: 02692e36f8334e9a
wp_post_id: 2348
wp_url: https://fivsevn.com/2026/03/04/4-march-2026-1808/
wp_slug: 4-march-2026-1808
status: published
---

改名字了：《AI话语分析》这样简洁、直接一点。<https://fivsevn-agy.github.io/fivsevn-devlog/posts/ai-discourse-analysis/>
